from setuptools import setup

setup(
    name='generate_message',
    version='1.0',
    description='Generating a message based on a preset text (based on Markov chains)',
    author='vavilovnv',
    author_email='forigb@yandex.ru',
    py_modules=['message_generation']
)
